let age: number = 45;
let nom: string = "Marie Claude Dugas";

console.log(age + " " + nom);
