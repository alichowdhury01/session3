const rls = require('readline-sync');

let nom = rls.question("Entrez votre nom : ");
console.log(`Votre nom est : ${nom}`);